RESPONSE_OK = 200
RESPONSE_BAD_REQUEST = 400
RESPONSE_FORBIDDEN = 403
RESPONSE_INTERNAL_SERVER_ERROR = 500

# TODO: 変数名が、たぶんおかしいので、考える。
JQUANTS_API_URI = 'https://api.jquants.com/v1' 
REFRESH_TOKEN_URL = '/token/auth_user'
ID_TOKEN_URL = '/token/auth_refresh'
